package model;

import java.util.Arrays;

public class Form 
{
	private String userName;
	private String password;
	private String repeatPassword;
	private int age;
	private String[] technologiesKnown;
	private String city;
	private String gender;
	private String workExperience;

	public Form()
	{
	}

	public Form(String userName, String password, String repeatPassword, int age, String[] technologiesKnown,
	String city, String gender, String workExperience) {
	super();
	this.userName = userName;
	this.password = password;
	this.repeatPassword = repeatPassword;
	this.age = age;
	this.technologiesKnown = technologiesKnown;
	this.city = city;
	this.gender = gender;
	this.workExperience = workExperience;
	}

	public String getUserName() {
	return userName;
	}
	public void setUserName(String userName) {
	this.userName = userName;
	}
	public String getPassword() {
	return password;
	}
	public void setPassword(String password) {
	this.password = password;
	}
	public String getRepeatPassword() {
	return repeatPassword;
	}
	public void setRepeatPassword(String repeatPassword) {
	this.repeatPassword = repeatPassword;
	}
	public int getAge() {
	return age;
	}
	public void setAge(int age) {
	this.age = age;
	}
	public String[] getTechnologiesKnown() {
	return technologiesKnown;
	}
	public void setTechnologiesKnown(String[] technologiesKnown) {
	this.technologiesKnown = technologiesKnown;
	}
	public String getCity() {
	return city;
	}
	public void setCity(String city) {
	this.city = city;
	}
	public String getGender() {
	return gender;
	}
	public void setGender(String gender) {
	this.gender = gender;
	}
	public String getWorkExperience() {
	return workExperience;
	}
	public void setWorkExperience(String workExperience) {
	this.workExperience = workExperience;
	}
	}