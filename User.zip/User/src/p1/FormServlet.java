package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Form;
import service.FormService;

/**
 * Servlet implementation class FormServlet
 */

public class FormServlet extends HttpServlet {
	public FormServlet()
	{
		super();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userName= request.getParameter("name");
		String password= request.getParameter("pass");
		String repassword= request.getParameter("repass");
		int empage= Integer.parseInt(request.getParameter("age"));
		String gender= request.getParameter("gender");
		String city = request.getParameter("city");
		String[] technologies = request.getParameterValues("select");
		String workExperience= request.getParameter("slider");

		Form form = new Form(userName,password,repassword,empage,technologies,city,gender,workExperience);
		String s1= new FormService().validateName(form);
		String s2= new FormService().validatePassword(form);
		String s3= (new FormService().validateAge(form));
		String s4 =new FormService().getProject(form.getTechnologiesKnown());


		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.print("Name: " +form.getUserName()+" "+s1+ "<br/>Age: "+form.getAge()+"--"+s3+ "<br/>Password: "+s2+"<br/>Project Assign: "+s4);
		 


		}

		}



