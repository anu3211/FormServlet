package service;

import java.util.Arrays;
import java.util.List;

import model.Form;

public class FormService 
{

	public String validateName(Form e) {
		
		String name=e.getUserName();
		
		char ch[]=name.toCharArray();
		String s="";
		if(ch.length<3)

		s="Invalid UserName";

		for(int i=0; i<ch.length;i++)
		{
		if(ch[i]=='0'|| ch[i]=='1'|| ch[i]=='2'|| ch[i]=='3'|| ch[i]=='4'|| ch[i]=='5'|| ch[i]=='6'||ch[i]=='7'|| ch[i]=='8'||
		ch[i]=='9')
		{
		s="Invalid UserName";
		}
		else if(ch[i]=='!'|| ch[i]=='@'|| ch[i]=='#'||ch[i]=='$'||ch[i]=='%'|| ch[i]=='^'|| ch[i]=='&'|| ch[i]=='*')
		{

		s="Invalid UserName";

		}
		

		}
		return s;
	}

	public String validateAge(Form e) {
	
		if(e.getAge()>18 && e.getAge()<60)
		{	
		return "Valid Age";
		}
		
		else
		{
		return "Invalid Age- Age is not between 18 and 60";
		}
	}  		

	public String validatePassword(Form e) {
	
		if((e.getPassword().equals(e.getRepeatPassword())))
		{
		return "Password matched";
		}
		else
		{
		return "Password doesnot match";
		}
	}
	

	public String getProject(String[] tech)
	{
		List<String> list = Arrays.asList(tech);
		if(list.contains("Java") && list.contains("Angular"))
			return "Java Full Stack Project";
		else if(list.contains("Python") && list.contains("R"))
			return "AI Project";
		else if(list.contains("Oracle"))
			return "DBA";
		else if(list.contains("Juniper"))
			return "Network Admin";
		return "No Project Assigned";
	}

}
